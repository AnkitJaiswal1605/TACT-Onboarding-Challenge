export * from '../build/CounterContract/tact_CounterContract';
